using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NFINDER.Nbios;

namespace NFINDER.NfinderAPI
{
    public static class Fetch
    {
       public static HttpClient client = new HttpClient();
       public static string api_key ="04f4e96eff0c450aa9a74b7301f72e57"; 

       public static string Data { get; set;}

       public static async Task GrabNewsAsync(string search) {
           ClearYourHead();

           HttpResponseMessage newsData =
           await client .GetAsync(
               "https://newsapi.org/v2/everything?apiKey=" + 
               api_key + "&q=" + search);

               if(newsData.IsSuccessStatusCode) {
                   Data = await newsData.Content.ReadAsStringAsync();
                   Nstat log= JsonConvert.DeserializeObject<Nstat>(Data);
                   Program.Nstat = JsonConvert.DeserializeObject<Nstat>(Data);
               }
               else {
                   Data = null;
               

               }

       }


       private static void ClearYourHead() {
           client.DefaultRequestHeaders.Accept.Clear();
           client.DefaultRequestHeaders.Accept.Add(
               new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(
                   "applicationException/json"));
                   
               
          }
    }

}

