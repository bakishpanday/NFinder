﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using NFINDER.NfinderAPI;
using NFINDER.Nbios;



namespace NFINDER.Pages
{
    public class IndexModel : PageModel
    {
        public List<Article> articles = new List<Article>();

        public void OnGet()
        {

        }
        public async Task OnPostGetNews(string search) {
            await Fetch.GrabNewsAsync(search);
            
            foreach( Article article in Program.Nstat.articles){
                articles.Add(article);
            }
        }

    }
} 
