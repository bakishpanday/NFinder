using System.Collections.Generic;

namespace NFINDER.Nbios {
    public class Nstat {
        
        public string status { get; set; }
        public int totalResults { get; set; }
        public List<Article> articles { get; set; }
       
    }
}